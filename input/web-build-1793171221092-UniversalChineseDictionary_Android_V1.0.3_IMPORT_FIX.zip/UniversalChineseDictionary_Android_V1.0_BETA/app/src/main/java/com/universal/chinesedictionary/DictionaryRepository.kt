package com.universal.chinesedictionary

import android.content.Context
import android.net.Uri
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

 data class Entry(
    val kind: String,
    val term: String,
    val pinyin: String = "",
    val traditional: String = "",
    val radical: String = "",
    val stroke: String = "",
    val structure: String = "",
    val definition: String = "",
    val extra: String = ""
)

class DictionaryRepository(private val context: Context) {
    private val dbFile = File(context.filesDir, "dict.db")
    @Volatile private var db: SQLiteDatabase? = null

    @Synchronized private fun database(): SQLiteDatabase {
        db?.let { if (it.isOpen) return it }
        if (!dbFile.exists()) {
            try {
                context.assets.open("databases/dict.db").use { input -> FileOutputStream(dbFile).use { input.copyTo(it) } }
            } catch (e: Exception) {
                throw IllegalStateException("尚未下载字典数据库。请在下方开启联网，然后点击‘下载/更新数据库’。", e)
            }
        }
        return SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY).also { db = it }
    }

    fun hasDatabase(): Boolean = dbFile.exists() || try { context.assets.open("databases/dict.db").close(); true } catch (_: Exception) { false }

    fun search(query: String): List<Entry> {
        val q = query.trim(); if (q.isEmpty()) return emptyList()
        val database = database(); val out = mutableListOf<Entry>()
        val like = "$q%"
        queryTable(database, "word", "hanzi", like, 30) { c -> Entry("汉字", c.str("hanzi"), c.str("pinyin"), c.str("traditional"), c.str("radical"), c.str("stroke"), c.str("structure"), c.str("definition"), c.str("example")) }.let(out::addAll)
        queryTable(database, "ci", "term", like, 30) { c -> Entry("词语", c.str("term"), c.str("pinyin"), definition=c.str("definition"), extra=c.str("example")) }.let(out::addAll)
        queryTable(database, "idiom", "term", like, 30) { c -> Entry("成语", c.str("term"), c.str("pinyin"), definition=c.str("definition"), extra=listOf(c.str("derivation"),c.str("example")).filter { it.isNotBlank() }.joinToString("\n")) }.let(out::addAll)
        if (out.isEmpty()) {
            val contains = "%$q%"
            queryTable(database, "word", "hanzi", contains, 20) { c -> Entry("汉字", c.str("hanzi"), c.str("pinyin"), c.str("traditional"), c.str("radical"), c.str("stroke"), c.str("structure"), c.str("definition"), c.str("example")) }.let(out::addAll)
            queryTable(database, "ci", "term", contains, 20) { c -> Entry("词语", c.str("term"), c.str("pinyin"), definition=c.str("definition"), extra=c.str("example")) }.let(out::addAll)
            queryTable(database, "idiom", "term", contains, 20) { c -> Entry("成语", c.str("term"), c.str("pinyin"), definition=c.str("definition"), extra=c.str("derivation")) }.let(out::addAll)
        }
        return out.distinctBy { "${it.kind}:${it.term}" }.take(60)
    }


    /** Import a compatible SQLite database, or one JSON dataset selected by the user. */
    fun importUserData(uri: Uri): String {
        val displayName = context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0).orEmpty() else ""
        }.orEmpty().ifBlank { "user-data.json" }
        val lower = displayName.lowercase()
        val temp = File(context.filesDir, "dict.import.tmp")
        temp.delete()
        if (lower.endsWith(".db") || lower.endsWith(".sqlite") || lower.endsWith(".sqlite3")) {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "无法读取所选文件" }
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            }
            val imported = SQLiteDatabase.openDatabase(temp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            try {
                val tables = mutableSetOf<String>()
                imported.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c -> while (c.moveToNext()) tables += c.getString(0) }
                if (!tables.containsAll(listOf("word", "ci", "idiom"))) error("SQLite 数据库必须包含 word、ci、idiom 三张表；请使用本词典格式的数据库")
                imported.rawQuery("SELECT hanzi FROM word LIMIT 0", null).close()
                imported.rawQuery("SELECT term FROM ci LIMIT 0", null).close()
                imported.rawQuery("SELECT term FROM idiom LIMIT 0", null).close()
            } finally { imported.close() }
            synchronized(this) {
                db?.close(); db = null
                if (dbFile.exists()) dbFile.delete()
                if (!temp.renameTo(dbFile)) { temp.copyTo(dbFile, overwrite = true); temp.delete() }
            }
            return "已导入数据库：$displayName"
        }
        require(lower.endsWith(".json")) { "请选择 .json 或兼容的 .db 文件" }
        val body = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法读取所选文件" }
            input.bufferedReader(Charsets.UTF_8).use { it.readText() }
        }
        val data: Any = if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body)
        val type = when {
            lower.contains("idiom") || lower.contains("chengyu") || lower.contains("成语") -> "idiom"
            lower.contains("word") || lower.contains("hanzi") || lower.contains("character") || lower.contains("汉字") -> "word"
            lower.contains("ci") || lower.contains("词语") || lower.contains("词典") -> "ci"
            else -> error("JSON 文件名请注明类型：word/汉字、ci/词语或 idiom/成语")
        }
        if (dbFile.exists()) dbFile.copyTo(temp, overwrite = true) else createEmptyDatabase(temp)
        val writable = SQLiteDatabase.openDatabase(temp.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
        val count: Int
        try {
            writable.delete(type, null, null)
            count = insertRows(writable, data, type)
            if (count == 0) error("没有识别到有效记录，请检查 JSON 字段")
        } finally { writable.close() }
        synchronized(this) {
            db?.close(); db = null
            if (dbFile.exists()) dbFile.delete()
            if (!temp.renameTo(dbFile)) { temp.copyTo(dbFile, overwrite = true); temp.delete() }
        }
        return "已导入 $displayName：$count 条记录（$type）；其他数据表已保留"
    }

    private fun createEmptyDatabase(file: File) {
        file.delete()
        val writable = SQLiteDatabase.openOrCreateDatabase(file, null)
        try {
            writable.execSQL("CREATE TABLE word (id INTEGER PRIMARY KEY, hanzi TEXT NOT NULL, pinyin TEXT DEFAULT '', traditional TEXT DEFAULT '', radical TEXT DEFAULT '', stroke TEXT DEFAULT '', structure TEXT DEFAULT '', definition TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_word_hanzi ON word(hanzi)")
            writable.execSQL("CREATE TABLE ci (id INTEGER PRIMARY KEY, term TEXT NOT NULL, pinyin TEXT DEFAULT '', definition TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_ci_term ON ci(term)")
            writable.execSQL("CREATE TABLE idiom (id INTEGER PRIMARY KEY, term TEXT NOT NULL, pinyin TEXT DEFAULT '', definition TEXT DEFAULT '', derivation TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_idiom_term ON idiom(term)")
        } finally { writable.close() }
    }

    /** Downloads public JSON datasets and builds a private SQLite database on-device. */
    fun downloadDatabase(progress: (String) -> Unit) {
        val datasets = listOf("word.json", "ci.json", "idiom.json").map { file ->
            progress("正在下载 $file…")
            fetchJson(file)
        }
        progress("正在建立本地数据库…")
        val temp = File(context.filesDir, "dict.db.tmp"); temp.delete()
        val writable = SQLiteDatabase.openOrCreateDatabase(temp, null)
        try {
            writable.execSQL("PRAGMA journal_mode=DELETE")
            writable.execSQL("CREATE TABLE word (id INTEGER PRIMARY KEY, hanzi TEXT NOT NULL, pinyin TEXT DEFAULT '', traditional TEXT DEFAULT '', radical TEXT DEFAULT '', stroke TEXT DEFAULT '', structure TEXT DEFAULT '', definition TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_word_hanzi ON word(hanzi)")
            writable.execSQL("CREATE TABLE ci (id INTEGER PRIMARY KEY, term TEXT NOT NULL, pinyin TEXT DEFAULT '', definition TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_ci_term ON ci(term)")
            writable.execSQL("CREATE TABLE idiom (id INTEGER PRIMARY KEY, term TEXT NOT NULL, pinyin TEXT DEFAULT '', definition TEXT DEFAULT '', derivation TEXT DEFAULT '', example TEXT DEFAULT '', raw_json TEXT DEFAULT '')")
            writable.execSQL("CREATE INDEX idx_idiom_term ON idiom(term)")
            val wordCount = insertRows(writable, datasets[0], "word")
            val ciCount = insertRows(writable, datasets[1], "ci")
            val idiomCount = insertRows(writable, datasets[2], "idiom")
            if (wordCount + ciCount + idiomCount == 0) error("下载的数据格式无法识别，请稍后重试。")
            progress("写入完成：汉字 $wordCount 条、词语 $ciCount 条、成语 $idiomCount 条")
        } finally { writable.close() }
        synchronized(this) {
            db?.close(); db = null
            if (dbFile.exists()) dbFile.delete()
            if (!temp.renameTo(dbFile)) { temp.copyTo(dbFile, overwrite=true); temp.delete() }
        }
    }

    private fun fetchJson(file: String): Any {
        val urls = listOf(
            "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/master/data/$file",
            "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/main/data/$file",
            "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/master/$file",
            "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/main/$file"
        )
        val errors = mutableListOf<String>()
        for (address in urls) {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(address).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000; conn.readTimeout = 45000
                conn.setRequestProperty("User-Agent", "UniversalChineseDictionary-Android/0.2")
                if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (body.isBlank()) error("返回内容为空")
                return if (body.trimStart().startsWith("[")) JSONArray(body) else JSONObject(body)
            } catch (e: Exception) { errors += "$address：${e.message}" }
            finally { conn?.disconnect() }
        }
        throw IllegalStateException("无法下载 $file。请检查网络或稍后重试。\n" + errors.take(2).joinToString("\n"))
    }

    private fun insertRows(db: SQLiteDatabase, data: Any, type: String): Int {
        val arr = when (data) {
            is JSONArray -> data
            is JSONObject -> {
                var found: JSONArray? = null
                for (key in listOf("data", "result", "words", "items")) if (data.opt(key) is JSONArray) { found = data.optJSONArray(key); break }
                found ?: JSONArray().also { a -> val keys=data.keys(); while(keys.hasNext()) { val k=keys.next(); val v=data.opt(k); if(v is JSONObject) a.put(v) } }
            }
            else -> JSONArray()
        }
        var count=0
        val sql = when(type) {
            "word" -> "INSERT INTO word(hanzi,pinyin,traditional,radical,stroke,structure,definition,example,raw_json) VALUES(?,?,?,?,?,?,?,?,?)"
            "ci" -> "INSERT INTO ci(term,pinyin,definition,example,raw_json) VALUES(?,?,?,?,?)"
            else -> "INSERT INTO idiom(term,pinyin,definition,derivation,example,raw_json) VALUES(?,?,?,?,?,?)"
        }
        db.beginTransaction()
        try {
            for (i in 0 until arr.length()) {
                val o=arr.optJSONObject(i) ?: continue
                fun value(vararg keys:String): String { for(k in keys) { val v=o.opt(k); if(v!=null && v!=JSONObject.NULL) { val s=if(v is String) v else v.toString(); if(s.isNotBlank()) return s } }; return "" }
                val term = if(type=="word") value("word","hanzi","character","name") else value("word","ci","idiom","term","name")
                if(term.isBlank()) continue
                val vals = when(type) {
                    "word" -> arrayOf(term,value("pinyin","pronunciation"),value("traditional","oldword","繁体","traditional_word"),value("radical","radicals","部首"),value("strokes","stroke","笔画"),value("structure","结构"),value("explanation","definition","释义","meaning"),value("example","more","例词"),o.toString())
                    "ci" -> arrayOf(term,value("pinyin"),value("explanation","definition","释义","meaning"),value("example","more","例句"),o.toString())
                    else -> arrayOf(term,value("pinyin"),value("explanation","definition","释义","meaning"),value("derivation","出处","source"),value("example","more","例句"),o.toString())
                }
                db.execSQL(sql, vals); count++
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return count
    }

    private fun queryTable(db: SQLiteDatabase, table:String, column:String, pattern:String, limit:Int, mapper:(Cursor)->Entry):List<Entry> {
        val result= mutableListOf<Entry>()
        db.rawQuery("SELECT * FROM $table WHERE $column LIKE ? LIMIT ?", arrayOf(pattern,limit.toString())).use { c -> while(c.moveToNext()) result += mapper(c) }
        return result
    }
    private fun Cursor.str(name:String):String { val i=getColumnIndex(name); return if(i>=0 && !isNull(i)) getString(i).orEmpty() else "" }
}
