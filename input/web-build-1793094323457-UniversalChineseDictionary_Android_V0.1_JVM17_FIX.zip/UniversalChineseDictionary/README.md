# Universal Chinese Dictionary Android V0.1

一个离线优先的 Android 汉字/词语/成语查询示例工程。数据库由 `converter/build_db.py` 从公开 GitHub 项目 `pwxcoo/chinese-xinhua` 下载 JSON 后转换生成。

## 环境
- Android Studio（建议最新版稳定版）
- JDK 17（Android Studio 通常自带）
- Android SDK Platform 35
- Python 3.9+（只在生成数据库时需要）
- 首次生成数据库需要联网；安装后的 App 查询本地 SQLite，不需要网络。

## 完整流程

### 1. 生成数据库
在项目根目录执行：

```bash
python3 -m pip install -r converter/requirements.txt
python3 converter/build_db.py
```

Windows PowerShell 可使用：

```powershell
py -m pip install -r converter/requirements.txt
py converter/build_db.py
```

脚本会尝试下载 `word.json`、`ci.json`、`idiom.json`，生成：

`app/src/main/assets/databases/dict.db`

如果 GitHub 主分支的文件路径变化，脚本会尝试仓库中的常见路径并给出明确错误；可在 `converter/build_db.py` 顶部调整下载地址。

### 2. 打开工程
Android Studio → Open → 选择 `UniversalChineseDictionary` 文件夹 → 等待 Gradle Sync 完成。

### 3. 运行
连接 Android 手机并开启开发者选项/USB 调试，点击 Run；也可使用 Android Studio 的 Device Manager 创建模拟器。

### 4. 编译 APK
Android Studio 菜单：Build → Build Bundle(s) / APK(s) → Build APK(s)。

Debug APK 通常位于：

`app/build/outputs/apk/debug/app-debug.apk`

也可在项目根目录执行：

```bash
./gradlew assembleDebug
```

Windows：

```powershell
.\gradlew.bat assembleDebug
```

注意：本 ZIP 不包含 Gradle Wrapper JAR，因此命令行构建需要先在 Android Studio 中同步工程并配置 Gradle，或通过 Android Studio 菜单构建。

## V0.1 当前功能
- 本地 SQLite 查询汉字、词语、成语
- 汉字拼音、繁体、部首、笔画、释义（字段取决于上游数据）
- 输入即搜、结果列表、详情页
- 查询历史（保存在 App 私有偏好设置中）
- 不要求运行时网络权限

## 数据与授权
数据来源项目： https://github.com/pwxcoo/chinese-xinhua
请在分发/修改/商用前查看上游仓库当前 LICENSE、数据来源说明及各数据文件的许可要求。此工程只提供下载转换脚本，不把上游原始数据打包进 ZIP。
