package com.universal.chinesedictionary

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.io.FileOutputStream

data class Entry(
    val kind: String,
    val term: String,
    val pinyin: String = "",
    val traditional: String = "",
    val radical: String = "",
    val stroke: String = "",
    val structure: String = "",
    val definition: String = "",
    val extra: String = ""
)

class DictionaryRepository(private val context: Context) {
    private val dbFile: File by lazy { File(context.filesDir, "dict.db") }
    @Volatile private var db: SQLiteDatabase? = null

    @Synchronized
    private fun database(): SQLiteDatabase {
        db?.let { if (it.isOpen) return it }
        if (!dbFile.exists()) {
            val assetPath = "databases/dict.db"
            try {
                context.assets.open(assetPath).use { input ->
                    FileOutputStream(dbFile).use { output -> input.copyTo(output) }
                }
            } catch (e: Exception) {
                throw IllegalStateException(
                    "找不到内置数据库。请先运行 converter/build_db.py 生成 app/src/main/assets/databases/dict.db。",
                    e
                )
            }
        }
        return SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY).also { db = it }
    }

    fun search(query: String): List<Entry> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val database = database()
        val out = mutableListOf<Entry>()
        val like = "$q%"
        queryTable(database, "word", "hanzi", like, 30) { c ->
            Entry("汉字", c.getStringOrEmpty("hanzi"), c.getStringOrEmpty("pinyin"),
                c.getStringOrEmpty("traditional"), c.getStringOrEmpty("radical"),
                c.getStringOrEmpty("stroke"), c.getStringOrEmpty("structure"),
                c.getStringOrEmpty("definition"), c.getStringOrEmpty("example"))
        }.let(out::addAll)
        queryTable(database, "ci", "term", like, 30) { c ->
            Entry("词语", c.getStringOrEmpty("term"), c.getStringOrEmpty("pinyin"),
                definition = c.getStringOrEmpty("definition"), extra = c.getStringOrEmpty("example"))
        }.let(out::addAll)
        queryTable(database, "idiom", "term", like, 30) { c ->
            Entry("成语", c.getStringOrEmpty("term"), c.getStringOrEmpty("pinyin"),
                definition = c.getStringOrEmpty("definition"),
                extra = listOf(c.getStringOrEmpty("derivation"), c.getStringOrEmpty("example"))
                    .filter { it.isNotBlank() }.joinToString("\n"))
        }.let(out::addAll)
        if (out.isEmpty()) {
            // Also allow substring matches if prefix search returned nothing.
            val contains = "%$q%"
            queryTable(database, "word", "hanzi", contains, 20) { c ->
                Entry("汉字", c.getStringOrEmpty("hanzi"), c.getStringOrEmpty("pinyin"),
                    c.getStringOrEmpty("traditional"), c.getStringOrEmpty("radical"),
                    c.getStringOrEmpty("stroke"), c.getStringOrEmpty("structure"),
                    c.getStringOrEmpty("definition"), c.getStringOrEmpty("example"))
            }.let(out::addAll)
            queryTable(database, "ci", "term", contains, 20) { c ->
                Entry("词语", c.getStringOrEmpty("term"), c.getStringOrEmpty("pinyin"),
                    definition = c.getStringOrEmpty("definition"), extra = c.getStringOrEmpty("example"))
            }.let(out::addAll)
            queryTable(database, "idiom", "term", contains, 20) { c ->
                Entry("成语", c.getStringOrEmpty("term"), c.getStringOrEmpty("pinyin"),
                    definition = c.getStringOrEmpty("definition"),
                    extra = c.getStringOrEmpty("derivation"))
            }.let(out::addAll)
        }
        return out.distinctBy { "${it.kind}:${it.term}" }.take(60)
    }

    private fun queryTable(
        db: SQLiteDatabase, table: String, column: String, pattern: String, limit: Int,
        mapper: (android.database.Cursor) -> Entry
    ): List<Entry> {
        val result = mutableListOf<Entry>()
        val sql = "SELECT * FROM $table WHERE $column LIKE ? LIMIT ?"
        db.rawQuery(sql, arrayOf(pattern, limit.toString())).use { cursor ->
            while (cursor.moveToNext()) result += mapper(cursor)
        }
        return result
    }

    private fun android.database.Cursor.getStringOrEmpty(name: String): String {
        val index = getColumnIndex(name)
        return if (index >= 0 && !isNull(index)) getString(index).orEmpty() else ""
    }
}
