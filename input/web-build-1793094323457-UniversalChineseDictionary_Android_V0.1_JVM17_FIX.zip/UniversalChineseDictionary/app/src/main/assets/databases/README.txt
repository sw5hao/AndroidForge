此目录需要由 converter/build_db.py 生成 dict.db。
生成前工程可同步，但运行 App 查询时会提示缺少数据库。
