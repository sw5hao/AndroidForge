#!/usr/bin/env python3
"""Download chinese-xinhua JSON datasets and build the app's SQLite database."""
from __future__ import annotations
import json
import sqlite3
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "app" / "src" / "main" / "assets" / "databases" / "dict.db"
CACHE = ROOT / "converter" / "download_cache"
BASES = [
    "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/master/data",
    "https://raw.githubusercontent.com/pwxcoo/chinese-xinhua/main/data",
]
FILES = {
    "word": ["word.json", "word.json"],
    "ci": ["ci.json", "ci.json"],
    "idiom": ["idiom.json", "idiom.json"],
}

def fetch_json(filename: str):
    CACHE.mkdir(parents=True, exist_ok=True)
    cached = CACHE / filename
    if cached.exists():
        try:
            return json.loads(cached.read_text(encoding="utf-8"))
        except Exception:
            cached.unlink(missing_ok=True)
    errors = []
    candidates = []
    for base in BASES:
        candidates += [f"{base}/{filename}", base.replace("/data", "") + f"/{filename}"]
    for url in candidates:
        try:
            req = Request(url, headers={"User-Agent": "UniversalChineseDictionary/0.1"})
            with urlopen(req, timeout=25) as response:
                raw = response.read()
            data = json.loads(raw.decode("utf-8-sig"))
            cached.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            print(f"Downloaded {filename} from {url}")
            return data
        except Exception as exc:
            errors.append(f"{url}: {exc}")
    raise RuntimeError(f"下载 {filename} 失败：\n" + "\n".join(errors))

def first(item, *keys, default=""):
    for key in keys:
        value = item.get(key)
        if value is not None and value != "":
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False)
            return str(value)
    return default

def as_list(data):
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        # Some mirrors wrap arrays under a named key.
        for key in ("data", "result", "words", "items"):
            if isinstance(data.get(key), list):
                return data[key]
        return list(data.values())
    return []

def main():
    datasets = {name: as_list(fetch_json(names[0])) for name, names in FILES.items()}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.unlink(missing_ok=True)
    conn = sqlite3.connect(OUT)
    try:
        conn.executescript("""
        PRAGMA journal_mode=DELETE;
        PRAGMA synchronous=NORMAL;
        CREATE TABLE word (
            id INTEGER PRIMARY KEY,
            hanzi TEXT NOT NULL,
            pinyin TEXT DEFAULT '',
            traditional TEXT DEFAULT '',
            radical TEXT DEFAULT '',
            stroke TEXT DEFAULT '',
            structure TEXT DEFAULT '',
            definition TEXT DEFAULT '',
            example TEXT DEFAULT '',
            raw_json TEXT DEFAULT ''
        );
        CREATE INDEX idx_word_hanzi ON word(hanzi);
        CREATE TABLE ci (
            id INTEGER PRIMARY KEY,
            term TEXT NOT NULL,
            pinyin TEXT DEFAULT '',
            definition TEXT DEFAULT '',
            example TEXT DEFAULT '',
            raw_json TEXT DEFAULT ''
        );
        CREATE INDEX idx_ci_term ON ci(term);
        CREATE TABLE idiom (
            id INTEGER PRIMARY KEY,
            term TEXT NOT NULL,
            pinyin TEXT DEFAULT '',
            definition TEXT DEFAULT '',
            derivation TEXT DEFAULT '',
            example TEXT DEFAULT '',
            raw_json TEXT DEFAULT ''
        );
        CREATE INDEX idx_idiom_term ON idiom(term);
        """)
        word_rows = []
        for x in datasets["word"]:
            if not isinstance(x, dict):
                continue
            hanzi = first(x, "word", "hanzi", "character", "name")
            if not hanzi:
                continue
            word_rows.append((
                hanzi, first(x, "pinyin", "pronunciation"),
                first(x, "traditional", "繁体", "traditional_word"),
                first(x, "radical", "部首"), first(x, "strokes", "stroke", "笔画"),
                first(x, "structure", "结构"), first(x, "explanation", "definition", "释义", "meaning"),
                first(x, "example", "例词"), json.dumps(x, ensure_ascii=False)
            ))
        conn.executemany("""INSERT INTO word
            (hanzi,pinyin,traditional,radical,stroke,structure,definition,example,raw_json)
            VALUES (?,?,?,?,?,?,?,?,?)""", word_rows)

        ci_rows = []
        for x in datasets["ci"]:
            if not isinstance(x, dict):
                continue
            term = first(x, "word", "ci", "term", "name")
            if term:
                ci_rows.append((term, first(x, "pinyin"), first(x, "explanation", "definition", "释义", "meaning"),
                                first(x, "example", "例句"), json.dumps(x, ensure_ascii=False)))
        conn.executemany("INSERT INTO ci(term,pinyin,definition,example,raw_json) VALUES (?,?,?,?,?)", ci_rows)

        idiom_rows = []
        for x in datasets["idiom"]:
            if not isinstance(x, dict):
                continue
            term = first(x, "word", "idiom", "term", "name")
            if term:
                idiom_rows.append((term, first(x, "pinyin"), first(x, "explanation", "definition", "释义", "meaning"),
                                   first(x, "derivation", "出处", "source"), first(x, "example", "例句"),
                                   json.dumps(x, ensure_ascii=False)))
        conn.executemany("INSERT INTO idiom(term,pinyin,definition,derivation,example,raw_json) VALUES (?,?,?,?,?,?)", idiom_rows)
        conn.commit()
        print(f"Database created: {OUT}")
        print(f"word={len(word_rows)}, ci={len(ci_rows)}, idiom={len(idiom_rows)}")
        if not word_rows and not ci_rows and not idiom_rows:
            raise RuntimeError("下载内容已解析，但没有识别到记录；请检查上游 JSON 字段格式。")
    finally:
        conn.close()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
