# Universal Chinese Dictionary Android V1.0 Beta 1

This is a consolidated **test build project**, not a precompiled APK. The build is intended to let the user install one APK and test the current integrated baseline.

## Implemented in this project
- Android Compose interface for searching Chinese characters, words and idioms.
- Search results and detail view with available pinyin, traditional form, radical, stroke count, structure, definition and examples.
- Local SQLite search once a database has been installed.
- In-app network permission toggle (application preference) and explicit database download/update button.
- Downloads public JSON files over HTTPS and attempts to create the SQLite database on device.
- Recent search history persisted locally.
- Java and Kotlin bytecode targets aligned to Java 17.
- Clear progress and failure messages for database download/build.

## Important test limitations
- This is V1.0 Beta, and has **not** been compiled or tested on a physical Android device in this environment.
- Database download depends on the upstream `pwxcoo/chinese-xinhua` repository paths and JSON schema. If upstream data structure changes, download/import may fail; please report the exact on-screen error and the AndroidForge log ZIP.
- The network switch controls this app's download feature; it cannot disable network access for the whole Android device.
- Not yet implemented in this beta: stroke-order animation, handwriting recognition, camera OCR, English dictionary with synonyms/antonyms, floating cross-app lookup, cloud AI explanations, and a complete offline dataset bundled in the APK. These require additional engines/data/services and are not represented as finished features.

## Build via AndroidForge
1. Upload this ZIP to AndroidForge.
2. Select `Android (APK)` and start a Debug build.
3. Download the generated APK artifact only after the workflow succeeds.

## First run
1. Install and open the APK.
2. Keep `允许联网` enabled.
3. Tap `下载/更新数据库` and keep the app open while it downloads and imports the data.
4. After the database-ready message, test character, word and idiom searches; then disable the app's network switch and repeat searches to test local lookup.

## Data source
https://github.com/pwxcoo/chinese-xinhua
Review upstream licensing and attribution requirements before redistributing or using commercially.
