package com.universal.chinesedictionary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = DictionaryRepository(applicationContext)
        val prefs = getSharedPreferences("dictionary", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF315B82),
                background = Color(0xFFF3F6FA),
                surface = Color.White
            )) {
                DictionaryScreen(
                    repository = repository,
                    initialHistory = prefs.getString("history", "").orEmpty()
                        .split("\n").filter { it.isNotBlank() }.take(12),
                    onHistoryChanged = { history -> prefs.edit().putString("history", history.joinToString("\n")).apply() }
                )
            }
        }
    }
}

@Composable
private fun DictionaryScreen(
    repository: DictionaryRepository,
    initialHistory: List<String>,
    onHistoryChanged: (List<String>) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var selected by remember { mutableStateOf<Entry?>(null) }
    var error by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(initialHistory) }
    var searching by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("dictionary", android.content.Context.MODE_PRIVATE) }
    var networkEnabled by remember { mutableStateOf(prefs.getBoolean("network_enabled", true)) }
    var downloading by remember { mutableStateOf(false) }
    var databaseStatus by remember { mutableStateOf(if (repository.hasDatabase()) "本地数据库已就绪" else "尚未下载数据库") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(query) {
        val q = query.trim()
        selected = null
        error = ""
        if (q.isEmpty()) {
            results = emptyList()
            searching = false
        } else {
            searching = true
            kotlinx.coroutines.delay(100)
            try {
                results = withContext(Dispatchers.IO) { repository.search(q) }
            } catch (e: Exception) {
                results = emptyList()
                error = e.message ?: "查询失败"
            } finally {
                searching = false
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Universal Chinese Dictionary", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF20364A))
                    Spacer(Modifier.height(4.dp))
                    Text("汉字 · 词语 · 成语查询", color = Color(0xFF68798A), fontSize = 14.sp)
                }
                OutlinedButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "返回" else "设置")
                }
            }
            Spacer(Modifier.height(10.dp))
            if (showSettings) Surface(color = Color.White, shape = RoundedCornerShape(14.dp), shadowElevation = 1.dp) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("联网与数据库", fontWeight = FontWeight.SemiBold, color = Color(0xFF20364A))
                            Text(databaseStatus, fontSize = 12.sp, color = Color(0xFF68798A))
                        }
                        Text("允许联网", fontSize = 13.sp)
                        Switch(checked = networkEnabled, onCheckedChange = {
                            networkEnabled = it
                            prefs.edit().putBoolean("network_enabled", it).apply()
                            databaseStatus = if (it) "已允许联网；可下载或更新数据库" else "联网已关闭；仅使用已下载的本地数据库"
                        })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(enabled = networkEnabled && !downloading, onClick = {
                            downloading = true
                            databaseStatus = "准备下载公开字典数据…"
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { repository.downloadDatabase { msg -> android.os.Handler(android.os.Looper.getMainLooper()).post { databaseStatus = msg } } }
                                    databaseStatus = "数据库下载完成，可以离线查询了"
                                    if (query.isNotBlank()) results = withContext(Dispatchers.IO) { repository.search(query.trim()) }
                                } catch (e: Exception) {
                                    databaseStatus = "下载失败：${e.message ?: "请检查网络后重试"}"
                                } finally { downloading = false }
                            }
                        }) { Text(if (downloading) "正在下载…" else "下载/更新数据库") }
                        Spacer(Modifier.width(10.dp))
                        Text("首次下载需要网络，完成后可离线使用", fontSize = 11.sp, color = Color(0xFF68798A))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 2.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it.take(30) },
                        modifier = Modifier.weight(1f).padding(vertical = 12.dp),
                        textStyle = LocalTextStyle.current.copy(fontSize = 18.sp, color = Color(0xFF172B3A)),
                        singleLine = true,
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text("输入汉字或词语", color = Color.Gray, fontSize = 18.sp)
                            inner()
                        }
                    )
                    TextButton(onClick = { query = ""; selected = null }) { Text("清除") }
                }
            }
            Spacer(Modifier.height(14.dp))
            if (error.isNotBlank()) {
                Text(error, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
            }
            selected?.let { entry ->
                DetailCard(entry = entry, onBack = { selected = null })
            } ?: run {
                when {
                    searching -> Text("查询中…", color = Color.Gray)
                    query.isNotBlank() && results.isEmpty() && error.isBlank() -> Text("没有找到匹配资料。若首次使用，请先开启联网并下载数据库。", color = Color.Gray)
                    query.isBlank() && history.isNotEmpty() -> {
                        Text("最近查询", fontWeight = FontWeight.SemiBold, color = Color(0xFF34495A))
                        Spacer(Modifier.height(8.dp))
                        history.forEach { item ->
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp).clickable { query = item },
                                color = Color.White, shape = RoundedCornerShape(12.dp)
                            ) { Text(item, Modifier.padding(13.dp), fontSize = 16.sp) }
                        }
                    }
                    else -> {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(results) { entry ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        selected = entry
                                        history = (listOf(entry.term) + history.filterNot { it == entry.term }).take(12)
                                        onHistoryChanged(history)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color.White,
                                    shadowElevation = 1.dp
                                ) {
                                    Column(Modifier.padding(14.dp)) {
                                        Row {
                                            Text(entry.term, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF20364A))
                                            Spacer(Modifier.width(10.dp))
                                            Text(entry.pinyin, fontSize = 14.sp, color = Color(0xFF527A9D), modifier = Modifier.padding(top = 5.dp))
                                            Spacer(Modifier.weight(1f))
                                            Text(entry.kind, fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(top = 5.dp))
                                        }
                                        if (entry.definition.isNotBlank()) {
                                            Spacer(Modifier.height(4.dp))
                                            Text(entry.definition, maxLines = 3, color = Color(0xFF465767), fontSize = 14.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailCard(entry: Entry, onBack: () -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 3.dp) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            TextButton(onClick = onBack) { Text("← 返回结果") }
            Text(entry.term, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color(0xFF20364A))
            if (entry.pinyin.isNotBlank()) Text(entry.pinyin, fontSize = 18.sp, color = Color(0xFF527A9D))
            Spacer(Modifier.height(12.dp))
            if (entry.traditional.isNotBlank()) InfoLine("繁体", entry.traditional)
            if (entry.radical.isNotBlank()) InfoLine("部首", entry.radical)
            if (entry.stroke.isNotBlank()) InfoLine("笔画", entry.stroke)
            if (entry.structure.isNotBlank()) InfoLine("结构", entry.structure)
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text("释义", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(5.dp))
            Text(entry.definition.ifBlank { "上游数据未提供释义字段。" }, fontSize = 15.sp, lineHeight = 23.sp)
            if (entry.extra.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                Text(if (entry.kind == "汉字") "例词" else "补充资料", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(entry.extra, fontSize = 14.sp, lineHeight = 21.sp)
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, modifier = Modifier.width(64.dp), color = Color(0xFF6C7C89))
        Text(value, color = Color(0xFF253B4D), fontWeight = FontWeight.Medium)
    }
}
